====================================================================================================
MediaInfoNET
====================================================================================================
MediaInfoNET.dll - http://teejeetech.blogspot.com/2013/01/mediainfo-wrapper-for-net-projects.html
Copyright (c) 2013 Tony George (teejee2008@gmail.com)

Add a reference to MediaInfoNET.dll to your VB.NET or C# project and copy MediaInfo.dll to the
application folder. Use the MediaFile class for reading information from audio and video files.

More information regarding usage, and examples are available on the following page:
http://teejeetech.blogspot.com/2013/01/mediainfo-wrapper-for-net-projects.html
====================================================================================================
3rd Party Software
====================================================================================================
MediaInfo.dll - http://mediainfo.sourceforge.net
Copyright (c) 2002-2012 MediaArea.net SARL, Info@MediaArea.net

MediaInfoNET is an independant software and is not related to the MediaInfo project in any way.
Please visit the MediaInfo website for more information related to the MediaInfo project.
====================================================================================================